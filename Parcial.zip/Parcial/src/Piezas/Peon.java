package Piezas;

public class Peon extends Piezas{

	public Peon(int posicionFila, int posicionColumna, String movimiento) {
		super(posicionFila, posicionColumna, movimiento);
		// TODO Auto-generated constructor stub
	}

}
