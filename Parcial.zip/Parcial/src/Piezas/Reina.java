package Piezas;

public class Reina extends Piezas{

	public Reina(int posicionFila, int posicionColumna, String movimiento) {
		super(posicionFila, posicionColumna, movimiento);
		// TODO Auto-generated constructor stub
	}

}
