package Piezas;

public class Torre extends Piezas{

	public Torre(int posicionFila, int posicionColumna, String movimiento) {
		super(posicionFila, posicionColumna, movimiento);
		// TODO Auto-generated constructor stub
	}

}
